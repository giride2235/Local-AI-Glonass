"""Portable Windows launcher. Paths are relative to this file, not the drive letter."""
import argparse,json,os,socket,subprocess,sys,time,urllib.request,webbrowser
from pathlib import Path
ROOT=Path(__file__).resolve().parent
STATE=ROOT/'state'
LOGS=ROOT/'logs'
MODEL='qwen3.5:4b'
API='http://127.0.0.1:11435'
WEB='http://127.0.0.1:8766'
HIDDEN=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0

def request(url,data=None):
    req=urllib.request.Request(url,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=10) as r:return json.load(r)

def available(port):
    with socket.socket() as s:
        try:s.bind(('127.0.0.1',port));return True
        except OSError:return False

def wait_ready(url,process,seconds=60):
    until=time.monotonic()+seconds
    while time.monotonic()<until:
        if process.poll() is not None:raise RuntimeError('Процесс завершился. Подробности в папке logs.')
        try:return request(url)
        except Exception:time.sleep(.5)
    raise RuntimeError('Сервис не запустился вовремя. Подробности в папке logs.')

def terminate(process):
    if process.poll() is None:
        if os.name=='nt':
            subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=HIDDEN)
        else:process.terminate()
        try:process.wait(timeout=15)
        except subprocess.TimeoutExpired:pass

def main():
    p=argparse.ArgumentParser()
    p.add_argument('action',nargs='?',default='start',choices=['start','stop','verify'])
    p.add_argument('--cpu',action='store_true')
    p.add_argument('--self-test',action='store_true')
    args=p.parse_args()
    if args.action=='verify':
        import hashlib
        records=json.loads((ROOT/'PACKAGE-MANIFEST.json').read_text(encoding='utf-8'))['files']
        errors=[]
        for i,item in enumerate(records):
            path=ROOT/item['path']
            if not path.is_file():errors.append(item['path']);continue
            digest=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
            if digest!=item['sha256']:errors.append(item['path'])
            if i%100==0:print(f'Проверено {i}/{len(records)}',flush=True)
        if errors:raise RuntimeError('Файлы повреждены или отсутствуют: '+', '.join(errors[:10]))
        print('Все файлы комплекта совпадают с контрольными суммами.')
        return
    STATE.mkdir(exist_ok=True);LOGS.mkdir(exist_ok=True)
    probe=STATE/'write-delete-check.tmp'
    try:
        probe.write_text('check',encoding='ascii')
        probe.unlink()
    except OSError as exc:
        raise RuntimeError('Нет права изменения файлов комплекта. Скопируйте всю папку на SSD в папку своей учётной записи и повторите запуск.') from exc
    stop=STATE/'stop.request'
    if args.action=='stop':
        stop.write_text('stop',encoding='ascii')
        print('Запрос остановки отправлен. Дождитесь закрытия окна START.')
        return
    for port in [11435,8766]:
        if not available(port):raise RuntimeError(f'Порт {port} занят. Если комплект уже запущен, откройте {WEB}. Чужой процесс автоматически не останавливается.')
    required=['runtime/python/python.exe','runtime/ollama/ollama.exe','app/scripts/review_server.py','models/manifests/registry.ollama.ai/library/qwen3.5/4b']
    for path in required:
        if not (ROOT/path).is_file():raise RuntimeError('Не найден файл '+path+'. Скопируйте всю папку комплекта.')
    stop.unlink(missing_ok=True)
    env=os.environ.copy()
    env.update(OLLAMA_HOST='127.0.0.1:11435',OLLAMA_MODELS=str(ROOT/'models'),GLONASS_OLLAMA_URL=API,GLONASS_WEB_PORT='8766',PYTHONUTF8='1',PYTHONNOUSERSITE='1',PYTHONPATH='',PYTHONHOME=str(ROOT/'runtime/python'),TEMP=str(STATE),TMP=str(STATE))
    if args.cpu:env['GLONASS_NUM_GPU']='0'
    else:env.pop('GLONASS_NUM_GPU',None)
    processes=[];handles=[]
    stamp=time.strftime('%Y%m%d-%H%M%S')
    def start(command,name):
        handle=(LOGS/(stamp+'-'+name+'.log')).open('wb');handles.append(handle)
        proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=handle,stderr=handle,creationflags=HIDDEN)
        processes.append(proc);return proc
    try:
        print('Запуск переносимой Ollama...',flush=True)
        ollama=start([str(ROOT/'runtime/ollama/ollama.exe'),'serve'],'ollama')
        tags=wait_ready(API+'/api/tags',ollama)
        if not any(m['name']==MODEL for m in tags['models']):raise RuntimeError('Модель не найдена в комплекте. Выполните VERIFY.cmd.')
        server=start([str(ROOT/'runtime/python/python.exe'),'-X','utf8','-s',str(ROOT/'app/scripts/review_server.py')],'website')
        status=wait_ready(WEB+'/api/status',server)
        if not status['ready']:raise RuntimeError('Сайт не обнаружил модель.')
        print('Готово: '+WEB+'\nПервый ответ может загружаться дольше.\nДля остановки нажмите Ctrl+C или запустите STOP.cmd.\nНе вынимайте флешку, пока комплект работает.',flush=True)
        if args.self_test:
            job=request(WEB+'/api/ask',{'question':'Учебная проверка переноса: нужен Excel с поездками. Это отчёт или ретрансляция?','rag':True,'model':MODEL})
            until=time.monotonic()+600
            while time.monotonic()<until:
                row=next(r for r in request(WEB+'/api/history') if r['id']==job['id'])
                if row['status']!='running':break
                time.sleep(1)
            else:raise RuntimeError('Истекло время проверочного ответа.')
            (LOGS/'portable-self-test.json').write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8')
            if row['status']!='done' or not row['result']['generation_complete']:raise RuntimeError(str(row.get('error','Незавершённый ответ')))
            if row['result']['source_ids']!=['operator:report_export']:raise RuntimeError('Неверный источник проверочного запроса.')
            print(row['result']['answer'],flush=True)
            print('SELF-TEST OK',flush=True)
            return
        webbrowser.open(WEB)
        while not stop.exists():
            if any(proc.poll() is not None for proc in processes):raise RuntimeError('Один из сервисов остановился. Смотрите logs.')
            time.sleep(.5)
    finally:
        for proc in reversed(processes):terminate(proc)
        for handle in handles:handle.close()
        stop.unlink(missing_ok=True)
        print('Процессы этого комплекта остановлены.',flush=True)

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:pass
    except Exception as exc:
        print('ОШИБКА: '+str(exc),flush=True)
        sys.exit(1)
