@echo off
chcp 65001 >nul
set "PYTHONHOME=%~dp0runtime\python"
set "PYTHONPATH="
"%~dp0runtime\python\python.exe" -X utf8 -s "%~dp0launcher.py" --cpu
if errorlevel 1 pause
